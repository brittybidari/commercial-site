$(document).ready(function () {
    $('.has-submenu').each(function () {
        $(this).hover(function () {
            $(this).toggleClass('show');
            $(this).children('.dropdown').toggleClass('show');

        });
    });
    $('.has-drop').each(function () {
        $(this).hover(function () {
            $(this).children('.web-sub').toggleClass('show');
        });

    });

    $('.burger-icon ').click(function () {
        $(this).parent('.site-header').toggleClass("full", "sticky");
        $(this).toggleClass('show');
        //$('.overlay-h').toggleClass('show');


    });

    if ($(window).width() >= 1024) {
        $('.has-megamenu').each(function () {

            $(this).children('.has-megamenu-overlay').mouseenter(function () {

                $('header.home').addClass('sticky');
                $('header').addClass('abs');
                // $(this).children('.mega-menu-wrap').addClass('show');
                $('.overlay-h').addClass('show');
                $(this).addClass('show');


                $(this).parent().addClass('active');
                $(this).parent().siblings().removeClass('active');
                $(this).parent().siblings().children().removeClass('show');


            });


            $(this).mouseleave(function () {

                $('header.home').removeClass('sticky');
                $('header').removeClass('abs');

                $(this).children('.has-megamenu-overlay').removeClass('show');
                $('.overlay-h').removeClass('show');


                $(this).removeClass('active');
                $(this).siblings().removeClass('active');
                $(this).siblings().children().removeClass('show');
            });
            $(this).children('.has-megamenu-overlay').on("click", function () {


                if ($(this).hasClass('show')) {
                    $('header.home').removeClass('sticky');
                    // $(this).children('.mega-menu-wrap').removeClass('show');
                    $('.overlay-h').removeClass('show');
                    $(this).removeClass('show');

                } else {
                    $('header.home').addClass('sticky');
                    // $(this).children('.mega-menu-wrap').addClass('show');
                    $('.overlay-h').addClass('show');
                    $(this).addClass('show');

                }
                $(this).parent().toggleClass('active');
                $(this).parent().siblings().removeClass('active');
                $(this).parent().siblings().children().removeClass('show');


            });
        });
        $('.overlay-h').click(function () {
            $('header.home').removeClass('sticky');
            $('.has-megamenu').children('.has-megamenu-overlay').removeClass('show');
            $('.has-megamenu').removeClass('show');
            $('.has-megamenu').siblings().removeClass('active');
            $('.has-megamenu').siblings().children().removeClass('show');
            $(this).toggleClass('show');

        });

    } else {
        $('.has-megamenu').each(function () {
            $(this).children('.has-megamenu-overlay').on("click", function () {


                $('header.home').addClass('sticky');
                // $(this).children('.mega-menu-wrap').addClass('show');
                $('.overlay-h').addClass('show');
                $(this).addClass('show');
                if ($(this).hasClass('show')) {

                    $(this).siblings('.arrow, .d-none').removeClass('d-none');

                }

                $(this).parent().addClass('active');
                $(this).parent().siblings().removeClass('active');
                $(this).parent().siblings().children().removeClass('show');


            });

            setTimeout(function () {
                $('.arrow').each(function () {

                    $(this).click(function () {

                        $(this).parent().removeClass('active');
                        $(this).siblings().removeClass('show');
                        $(this).addClass('d-none');
                    });
                }, 1000);
            });

        });

        $('.overlay-h').click(function () {

            $('.burger-icon ').parent('.site-header').removeClass("full", "sticky");
            $('.burger-icon ').removeClass('show');
            $('.overlay-h').removeClass('show');

        });

    }


    $('.newsletter-form').hover(function () {
        $(this).children('.newsletter-form__control').toggleClass('rollover');
    });


// for the init of the slider

    $(document).ready(function () {


        var absoluteimage = new Swiper('.absolute-slider-image', {
            effect: 'fade',


        });
        var absolutequote = new Swiper('.absolute-slider-quote', {
            effect: 'fade',
            speed: 600,
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
                type: 'bullets',
            },


            autoplay: {}
        });
        absoluteimage.controller.control = absolutequote;
        absolutequote.controller.control = absoluteimage;

        var twitter = new Swiper('.feed-slider', {
            effect: 'fade',
            speed: 600,
            pagination: {
                el: '.navigation',
                clickable: true,
                type: 'bullets',
            },

            autoplay: {}
        });


        var multislide = new Swiper('.multi-slide', {
            slidesPerView: 6,
            speed: 600,
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },

            pagination: {
                el: '.swiper-pagination',
                type: 'fraction',
            },

            breakpoints: {
                1024: {
                    slidesPerView: 6,
                    spaceBetween: 40,
                },
                768: {
                    slidesPerView: 3,
                    spaceBetween: 30,
                },

                360: {
                    slidesPerView: 2,
                }
            }

        });


    });


// for the youtube full video


    /* Adding body class to disable newsletter pop-up for pop-up video */


    /**
     * Check if video is from youtube or vimeo and play them on click on button
     */

    function checkUrl(url) {
        var host;
        if (url.indexOf('youtube.com') !== -1) {
            host = 'youtube';

        } else if (url.indexOf('vimeo.com') !== -1) {
            host = 'vimeo';
        } else if (url.indexOf('dailymotion.com') !== -1) {
            host = 'dailymotion';
        } else {
            host = 'none';
        }
        return host;
    }

    function parseVideo(url) {
        /*url.match(/(http:\/\/|https:\/\/|)(player.|www.)?(vimeo\.com|youtu(be\.com|\.be|be\.googleapis\.com))\/(video\/|embed\/|watch\?v=|v\/)?([A-Za-z0-9._%-]*)(\&\S+)?/);
        var type = null;
        if (RegExp.$3.indexOf('youtu') > -1) {
            type = 'youtube';
        } else if (RegExp.$3.indexOf('vimeo') > -1) {
            type = 'vimeo';
        }
        return {
            type: type,
            id: RegExp.$6
        };*/
        var videoURL = url.match(/(youtube|youtu|vimeo|dailymotion|dai|kickstarter)\.(com|be|ly)\/((watch\?v=([-\w]+))|(video\/([-\w]+))|(projects\/([-\w]+)\/([-\w]+))|([-\w]+))/);
        var src = null;
        if (videoURL[1] == 'youtube') {
            src = 'https://www.youtube.com/embed/' + videoURL[5] + '?showinfo=0&rel=0&autoplay=1&mute=1&enablejsapi=1';
        }

        if (videoURL[1] == 'youtu') {
            src = 'https://www.youtube.com/embed/' + videoURL[3] + '?showinfo=0&rel=0&autoplay=1&mute=1&enablejsapi=1';
        }

        if (videoURL[1] == 'vimeo') {
            src = 'https://player.vimeo.com/video/' + videoURL[3] + '?autoplay=1&loop=1&autopause=0';
        }

        if (videoURL[1] == 'dailymotion') {
            src = 'https://dailymotion.com/embed/video/' + videoURL[7];
        }

        if (videoURL[1] == 'dai') {
            src = 'https://www.dailymotion.com/embed/video/' + videoURL[3];
        }

        if (videoURL[1] == 'kickstarter') {
            src = 'https://www.kickstarter.com/projects/' + videoURL[9] + '/' + videoURL[10] + '/widget/video.html';
        }

        return src;
    }

    function playYoutubeVimeoVideo() {
        [].forEach.call(document.querySelectorAll('.js-video-play'), function (elem) {
            elem.addEventListener('click', function (e) {
                e.currentTarget.classList.add('d-none');
                e.currentTarget.parentNode.classList.add('is-playing');
                var url = parseVideo(e.currentTarget.getAttribute('data-src'));
                if (url) {
                    e.currentTarget.parentNode.querySelector('.js-embed-responsive-player').setAttribute('src', url);
                } else {
                    return;
                }
                /*var urlCheck = parseVideo(e.currentTarget.getAttribute('data-src'));
                if (urlCheck.type === 'youtube') {
                    var url = 'https://www.youtube.com/embed/' + urlCheck.id;
                    e.currentTarget.parentNode.querySelector('.js-embed-responsive-player').setAttribute('src', url + '?showinfo=0&rel=0&autoplay=1&mute=1&enablejsapi=1');
                } else if (urlCheck.type === 'vimeo') {
                    var url = 'https://player.vimeo.com/video/' + urlCheck.id;
                    e.currentTarget.parentNode.querySelector('.js-embed-responsive-player').setAttribute('src', url + '?autoplay=1&loop=1&autopause=0');
                } else {
                    var re = /(?:dailymotion\.com(?:\/video|\/hub)|dai\.ly)\/([0-9a-z]+)(?:[\-_0-9a-zA-Z]+#video=([a-z0-9]+))?/g;
                    var dailymotion = re.exec(e.currentTarget.getAttribute('data-src'));
                    var videoId = dailymotion[1];
                    var url = 'https://dailymotion.com/embed/video/' + videoId;
                    e.currentTarget.parentNode.querySelector('.js-embed-responsive-player').setAttribute('src', url + '?autoplay=1&loop=1&autopause=0');
                    return;
                }*/

                e.preventDefault();
            });
        });


    }

    playYoutubeVimeoVideo();

// init Isotope
    var $grid = $('.grid').isotope({
        itemSelector: '.card-filter',


    });

// filter functions
    var filterFns = {
        // show if number is greater than 50
        numberGreaterThan50: function () {
            var number = $(this).find('.number').text();
            return parseInt(number, 10) > 50;
        }
    };

// bind filter button click
    $('#filters').on('click', 'button', function () {
        var filterValue = $(this).attr('data-filter');
        // use filterFn if matches value
        filterValue = filterFns[filterValue] || filterValue;
        $grid.isotope({filter: filterValue});
    });


    $('#filters').children('.btn').each(function () {
        $(this).click(function () {
            if ($(this).hasClass('active')) {
                $('.grid').addClass('d-none');
                $(this).removeClass('active');


            } else {
                $('.grid').removeClass('d-none');
                $(this).addClass('active');

            }
            $(this).siblings('.btn').removeClass('active');
        });


    });


// change is-checked class on buttons


// for select in the form
    $('.js-example-basic-single').select2({

        minimumResultsForSearch: -1,
        placeholder: 'Select a page',

    });
    $('.js-example-basic-single').dropdown.slideDown("slow");
    $('.js-example-basic-single').dropdown.slideUp("slow");

    $('.form-control-select').select2({

        minimumResultsForSearch: -1
    });


});