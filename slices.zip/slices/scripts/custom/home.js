

    if ($(window).width() >= 1024) {
        $(window).scroll(function () {
            var sticky = $('.site-header'),
                scroll = $(window).scrollTop();

            if ((scroll > 133) || ($('.has-megamenu-overlay').hasClass('show'))) sticky.addClass('sticky');
            else sticky.removeClass('sticky');


        });
    }

    $(document).ready(function () {
        if ($(window).width() < 1024) {
            $(window).scroll(function () {
                var sticky = $('.site-header');
                var logoSticky = $('.logo-wrap');
                scroll = $(window).scrollTop();


                if ((scroll > 52)) {
                    sticky.addClass('sticky');
                    logoSticky.addClass('sticky');
                } else {
                    sticky.removeClass('sticky');
                    logoSticky.removeClass('sticky');
                }


            });
        }
    });

    var imageSwiper = new Swiper('.image-slider', {
       // effect: 'slide',
        allowTouchMove: true,
    });
    var quoteSwiper = new Swiper('.quote-slider', {
        effect: 'fade',
        speed: 1000,
        watchOverflow : true,

        allowTouchMove: true,
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
            type: 'bullets',
        },
        autoplay: {},



    });

    imageSwiper.controller.control = quoteSwiper;
    quoteSwiper.controller.control = imageSwiper;
